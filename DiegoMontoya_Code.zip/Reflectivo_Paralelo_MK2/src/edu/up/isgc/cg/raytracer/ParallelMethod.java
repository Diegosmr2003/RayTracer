package edu.up.isgc.cg.raytracer;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ParallelMethod {

    public static void Parallel(){
        ExecutorService executorService = Executors.newFixedThreadPool(8);
    }


}
